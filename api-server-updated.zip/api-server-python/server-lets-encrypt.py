"""
SELRS API Server with Let's Encrypt SSL/HTTPS Support
Connects to MS Access database via pyodbc
"""

from flask import Flask, request, jsonify
from flask_cors import CORS
import pyodbc
import jwt
import ssl
import os
from datetime import datetime, timedelta
from functools import wraps
import json

app = Flask(__name__)
CORS(app)

# ===== Configuration =====
SECRET_KEY = "selrs2024"
ALGORITHM = "HS256"

# Let's Encrypt Certificate Paths (Windows)
CERT_FILE = r"C:\Certbot\live\selrs.cc\fullchain.pem"
KEY_FILE = r"C:\Certbot\live\selrs.cc\privkey.pem"

# Database Configuration
DB_PATH = r"C:\Users\selrs\OneDrive\Documents\SELRS\SELRS.accdb"
CONNECTION_STRING = f"Driver={{Microsoft Access Driver (*.mdb, *.accdb)}};DBQ={DB_PATH};"

# ===== Helper Functions =====

def get_db_connection():
    """Create and return database connection"""
    try:
        conn = pyodbc.connect(CONNECTION_STRING)
        return conn
    except Exception as e:
        print(f"Database connection error: {str(e)}")
        return None

def token_required(f):
    """Decorator to check JWT token"""
    @wraps(f)
    def decorated(*args, **kwargs):
        token = None
        
        if 'Authorization' in request.headers:
            auth_header = request.headers['Authorization']
            try:
                token = auth_header.split(" ")[1]
            except IndexError:
                return jsonify({'message': 'Invalid token format'}), 401
        
        if not token:
            return jsonify({'message': 'Token is missing'}), 401
        
        try:
            data = jwt.decode(token, SECRET_KEY, algorithms=[ALGORITHM])
            current_user = data['user']
        except jwt.ExpiredSignatureError:
            return jsonify({'message': 'Token has expired'}), 401
        except jwt.InvalidTokenError:
            return jsonify({'message': 'Invalid token'}), 401
        
        return f(current_user, *args, **kwargs)
    
    return decorated

# ===== Authentication Routes =====

@app.route('/api/login', methods=['POST'])
@app.route('/api/auth/login', methods=['POST'])
def login():
    """Login endpoint - returns JWT token"""
    data = request.get_json()
    
    username = data.get('username')
    password = data.get('password')
    
    # Accept any username and password for testing
    # TODO: Replace with actual database authentication
    if username and password:
        token = jwt.encode(
            {
                'user': username,
                'exp': datetime.utcnow() + timedelta(days=7)
            },
            SECRET_KEY,
            algorithm=ALGORITHM
        )
        return jsonify({'token': token, 'user': username}), 200
    
    return jsonify({'message': 'Username and password required'}), 400

@app.route('/api/health', methods=['GET'])
def health():
    """Health check endpoint"""
    return jsonify({
        'status': 'ok',
        'timestamp': datetime.now().isoformat(),
        'ssl': 'enabled',
        'server': 'SELRS API Server'
    }), 200

# ===== Sulf (السلف) Routes =====

@app.route('/api/sulf', methods=['GET'])
@token_required
def get_sulf(current_user):
    """Get all Sulf records"""
    conn = get_db_connection()
    if not conn:
        return jsonify({'message': 'Database connection failed'}), 500
    
    try:
        cursor = conn.cursor()
        cursor.execute("""
            SELECT [الرقم], [الاسم], [المبلغ], [التاريخ], [الملاحظات]
            FROM [السلف]
            ORDER BY [التاريخ] DESC
        """)
        
        columns = [desc[0] for desc in cursor.description]
        records = []
        for row in cursor.fetchall():
            records.append(dict(zip(columns, row)))
        
        return jsonify(records), 200
    except Exception as e:
        return jsonify({'message': f'Error: {str(e)}'}), 500
    finally:
        conn.close()

@app.route('/api/sulf/<int:id>', methods=['GET'])
@token_required
def get_sulf_by_id(current_user, id):
    """Get specific Sulf record"""
    conn = get_db_connection()
    if not conn:
        return jsonify({'message': 'Database connection failed'}), 500
    
    try:
        cursor = conn.cursor()
        cursor.execute("""
            SELECT [الرقم], [الاسم], [المبلغ], [التاريخ], [الملاحظات]
            FROM [السلف]
            WHERE [الرقم] = ?
        """, (id,))
        
        row = cursor.fetchone()
        if not row:
            return jsonify({'message': 'Record not found'}), 404
        
        columns = [desc[0] for desc in cursor.description]
        record = dict(zip(columns, row))
        
        return jsonify(record), 200
    except Exception as e:
        return jsonify({'message': f'Error: {str(e)}'}), 500
    finally:
        conn.close()

@app.route('/api/sulf', methods=['POST'])
@token_required
def create_sulf(current_user):
    """Create new Sulf record"""
    data = request.get_json()
    conn = get_db_connection()
    if not conn:
        return jsonify({'message': 'Database connection failed'}), 500
    
    try:
        cursor = conn.cursor()
        cursor.execute("""
            INSERT INTO [السلف] ([الاسم], [المبلغ], [التاريخ], [الملاحظات])
            VALUES (?, ?, ?, ?)
        """, (
            data.get('الاسم'),
            data.get('المبلغ'),
            data.get('التاريخ'),
            data.get('الملاحظات', '')
        ))
        
        conn.commit()
        return jsonify({'message': 'Record created successfully'}), 201
    except Exception as e:
        conn.rollback()
        return jsonify({'message': f'Error: {str(e)}'}), 500
    finally:
        conn.close()

# ===== Qard (القرض) Routes =====

@app.route('/api/qard', methods=['GET'])
@token_required
def get_qard(current_user):
    """Get all Qard records"""
    conn = get_db_connection()
    if not conn:
        return jsonify({'message': 'Database connection failed'}), 500
    
    try:
        cursor = conn.cursor()
        cursor.execute("""
            SELECT [الرقم], [الاسم], [المبلغ], [السداد], [التاريخ], [الملاحظات]
            FROM [القرض]
            ORDER BY [التاريخ] DESC
        """)
        
        columns = [desc[0] for desc in cursor.description]
        records = []
        for row in cursor.fetchall():
            record = dict(zip(columns, row))
            # Calculate remaining amount
            record['المتبقي'] = record.get('المبلغ', 0) - record.get('السداد', 0)
            records.append(record)
        
        return jsonify(records), 200
    except Exception as e:
        return jsonify({'message': f'Error: {str(e)}'}), 500
    finally:
        conn.close()

@app.route('/api/qard/<int:id>', methods=['GET'])
@token_required
def get_qard_by_id(current_user, id):
    """Get specific Qard record"""
    conn = get_db_connection()
    if not conn:
        return jsonify({'message': 'Database connection failed'}), 500
    
    try:
        cursor = conn.cursor()
        cursor.execute("""
            SELECT [الرقم], [الاسم], [المبلغ], [السداد], [التاريخ], [الملاحظات]
            FROM [القرض]
            WHERE [الرقم] = ?
        """, (id,))
        
        row = cursor.fetchone()
        if not row:
            return jsonify({'message': 'Record not found'}), 404
        
        columns = [desc[0] for desc in cursor.description]
        record = dict(zip(columns, row))
        # Calculate remaining amount
        record['المتبقي'] = record.get('المبلغ', 0) - record.get('السداد', 0)
        
        return jsonify(record), 200
    except Exception as e:
        return jsonify({'message': f'Error: {str(e)}'}), 500
    finally:
        conn.close()

@app.route('/api/qard', methods=['POST'])
@token_required
def create_qard(current_user):
    """Create new Qard record"""
    data = request.get_json()
    conn = get_db_connection()
    if not conn:
        return jsonify({'message': 'Database connection failed'}), 500
    
    try:
        cursor = conn.cursor()
        cursor.execute("""
            INSERT INTO [القرض] ([الاسم], [المبلغ], [السداد], [التاريخ], [الملاحظات])
            VALUES (?, ?, ?, ?, ?)
        """, (
            data.get('الاسم'),
            data.get('المبلغ'),
            data.get('السداد', 0),
            data.get('التاريخ'),
            data.get('الملاحظات', '')
        ))
        
        conn.commit()
        return jsonify({'message': 'Record created successfully'}), 201
    except Exception as e:
        conn.rollback()
        return jsonify({'message': f'Error: {str(e)}'}), 500
    finally:
        conn.close()

@app.route('/api/qard/<int:id>', methods=['PUT'])
@token_required
def update_qard(current_user, id):
    """Update Qard record"""
    data = request.get_json()
    conn = get_db_connection()
    if not conn:
        return jsonify({'message': 'Database connection failed'}), 500
    
    try:
        cursor = conn.cursor()
        cursor.execute("""
            UPDATE [القرض]
            SET [الاسم] = ?, [المبلغ] = ?, [السداد] = ?, [الملاحظات] = ?
            WHERE [الرقم] = ?
        """, (
            data.get('الاسم'),
            data.get('المبلغ'),
            data.get('السداد'),
            data.get('الملاحظات', ''),
            id
        ))
        
        conn.commit()
        return jsonify({'message': 'Record updated successfully'}), 200
    except Exception as e:
        conn.rollback()
        return jsonify({'message': f'Error: {str(e)}'}), 500
    finally:
        conn.close()

@app.route('/api/qard/<int:id>', methods=['DELETE'])
@token_required
def delete_qard(current_user, id):
    """Delete Qard record"""
    conn = get_db_connection()
    if not conn:
        return jsonify({'message': 'Database connection failed'}), 500
    
    try:
        cursor = conn.cursor()
        cursor.execute("DELETE FROM [القرض] WHERE [الرقم] = ?", (id,))
        conn.commit()
        return jsonify({'message': 'Record deleted successfully'}), 200
    except Exception as e:
        conn.rollback()
        return jsonify({'message': f'Error: {str(e)}'}), 500
    finally:
        conn.close()

# ===== Error Handlers =====

@app.errorhandler(404)
def not_found(error):
    return jsonify({'message': 'Endpoint not found'}), 404

@app.errorhandler(500)
def internal_error(error):
    return jsonify({'message': 'Internal server error'}), 500

# ===== Main =====

if __name__ == '__main__':
    print("\n" + "="*60)
    print("SELRS API Server - Let's Encrypt HTTPS")
    print("="*60)
    
    # Check certificate files
    if not os.path.exists(CERT_FILE):
        print(f"\n❌ Certificate not found: {CERT_FILE}")
        print("\nTo fix this:")
        print("1. Install Certbot: pip install certbot")
        print("2. Run: certbot certonly --standalone -d selrs.cc")
        print("3. Update CERT_FILE path in this script")
        exit(1)
    
    if not os.path.exists(KEY_FILE):
        print(f"\n❌ Private key not found: {KEY_FILE}")
        print("Check your Let's Encrypt installation")
        exit(1)
    
    print(f"\n✅ Certificate found: {CERT_FILE}")
    print(f"✅ Private key found: {KEY_FILE}")
    
    # Create SSL context
    try:
        ssl_context = ssl.SSLContext(ssl.PROTOCOL_TLS_SERVER)
        ssl_context.load_cert_chain(CERT_FILE, KEY_FILE)
        print("✅ SSL context created successfully")
    except Exception as e:
        print(f"❌ SSL error: {str(e)}")
        exit(1)
    
    # Check database connection
    conn = get_db_connection()
    if conn:
        print(f"✅ Database connection successful: {DB_PATH}")
        conn.close()
    else:
        print(f"⚠️  Database connection failed: {DB_PATH}")
        print("   Server will start but database operations will fail")
    
    print("\n" + "="*60)
    print("🔒 Starting HTTPS server...")
    print("="*60)
    print("📍 Local:   https://0.0.0.0:3000")
    print("🌐 Domain:  https://selrs.cc:3000")
    print("📱 Mobile:  Use 'https://selrs.cc:3000' in app settings")
    print("\n⚠️  Press Ctrl+C to stop the server\n")
    
    app.run(
        host='0.0.0.0',
        port=3000,
        ssl_context=ssl_context,
        debug=False
    )
